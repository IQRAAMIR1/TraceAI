import { Link } from 'react-router-dom';
import { ShieldCheck, Menu } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import NotificationBell from './NotificationBell';

export default function Navbar() {
  const { user, signOut } = useAuth();

  return (
    <div className="topbar">
      <Link to="/" className="brand">
        <span className="brand-icon">
          <ShieldCheck size={22} color="#fff" />
        </span>
        <span>
          <span className="brand-name">
            Trace<span>AI</span>
          </span>
          <br />
          <span className="brand-tagline">AI-Powered Recovery</span>
        </span>
      </Link>
      <nav className="topbar-nav" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <Link to="/browse">Browse</Link>
        <Link to="/sighting">Report a Sighting</Link>
        <Link to="/map">Hotspot Map</Link>

        {user ? (
          <>
            <NotificationBell />
            <Link to="/dashboard">Dashboard</Link>
            <button
              onClick={() => signOut()}
              style={{
                background: 'transparent',
                border: '1px solid #fff',
                color: '#fff',
                borderRadius: '999px',
                padding: '6px 14px',
                cursor: 'pointer',
              }}
            >
              Logout
            </button>
          </>
        ) : (
          <Link to="/auth">Login / Sign Up</Link>
        )}
      </nav>
      <button className="back-link" aria-label="Menu" style={{ display: 'none' }}>
        <Menu size={20} />
      </button>
    </div>
  );
}